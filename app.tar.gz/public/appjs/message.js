Vue.config.devtools = true;

new Vue({
    el: '#app',
    data () {
        return {
            
        }
    },
    mounted () {
    },
    methods: {
        
    }
});