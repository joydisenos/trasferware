El desarrollo del proyecto tienen como primera etapa, la implementación de la estructura de control de los usuarios que interactuaran con el sistema.

1. Desarrollo del las interfaces central del proyecto, para que sea escalable a largo plazo.

* Creación de la db y sus tablas a través de un algoritmo de migraciones para que tenga la  flexibilidad de usar cualquier gestor, predeterminado MySql.

* Se define los css y estilos a usar.

* Se crean los layout de html.

2. Se definen los roles en el sistema y se crean las estructuras para su asignación a usuarios.

3. Se desarrolla la interfaces de creación de usuarios y asignación de roles y permisos.

* Cada usuario tendrá un rol determinado por el departamento asignado y permisos con los que podrá interactuar con la información.
  * Visualizar, Crear, Actualizar, Eliminar.

4. Están comprendidos los siguientes departamentos, aunque pueden aumentar.

    Dirección General.
    Consultoría Jurídica.
    Oficina de planificación y presupuesto.
    Oficina de Gestión administrativa.
    Oficina de  Gestión Humana.
    Oficina de Atención Ciudadano.
    Oficina de Seguimiento Evaluación Control de Obras
