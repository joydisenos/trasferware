<div v-if="spin">
    <div class="row text-center">
        <div class="col-lg-offset-4 col-lg-4 spin">
            <i class="fa fa-spinner fa-spin fa-3x"></i>
        </div>
    </div>
</div>
