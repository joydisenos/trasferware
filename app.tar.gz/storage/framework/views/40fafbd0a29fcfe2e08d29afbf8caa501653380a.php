<?php $__env->startSection('content'); ?>
  <div class="row">
        <div class="col-xs-12">
            <div class="content-tabla">
                <div class="panel panel-border panel-inverse" style="margin-top: 5px">
                    <div class="panel-heading">
                        <h4><strong>De: </strong><?php echo e($mensaje->name); ?></h4>
                    </div>
                    <div style="border-bottom: solid 1px"></div>
                    <div style="margin: 1.5em">
                        <?php echo html_entity_decode($mensaje->body); ?>

                    <?php if($mensaje->path_file): ?>
                        <br>
                        <h5>Archivo adjunto</h5>
                        <a href="<?php echo e(route('download_file', [$mensaje->path_file])); ?>"><?php echo e($mensaje->path_file); ?></a>
                    <?php endif; ?>
                    </div>
                </div>
                <a href="<?php echo e(route('mensaje')); ?>" class="btn btn-primary btn-sm"><i class="mdi mdi-cisco-webex"></i> Volver</a>
            </div>
        </div>
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>