<?php $__env->startSection('content'); ?>
  <div class="row">
        <div class="col-xs-12">
            <div class="page-title-box">
                <h4 class="page-title">Mensajes</h4>
                <ol class="breadcrumb p-0 m-0">
                    <li>
                        <a href="#">Wusi</a>
                    </li>
                    <li>
                        <a href="#">Mensajes</a>
                    </li>
                </ol>
                <div class="clearfix"></div>
            </div>
        </div>
  </div>
  <div class="tabpanel">
        <div class="col-md-2">
            <ul class="nav nav-pills nav-stacked">
                <li><a href="<?php echo e(route('crear')); ?>">Redactar</a></li>
                <li><a href="<?php echo e(route('mensaje')); ?>">Recibidos</a></li>
                <li><a href="#">Borradores</a></li>
                <li class="active"><a href="<?php echo e(route('enviados')); ?>">Enviados</a></li>
            </ul>
        </div>
        <div class="col-md-10">
                <?php if(Session::has('send_success_message')): ?>
                    <div class="alert alert-success">
                            <p><?php echo e(Session::get('send_success_message')); ?></p>
                        </div>
                <?php elseif(Session::has('send_error_message')): ?>
                        <div class="alert alert-danger">
                            <p> <?php echo e(Session::get('send_error_message')); ?></p>
                        </div>
                <?php elseif(Session::has('delete_success_message')): ?>
                        <div class="alert alert-success">
                            <p> <?php echo e(Session::get('delete_success_message')); ?></p>
                        </div>
                <?php elseif(Session::has('delete_error_message')): ?>
                        <div class="alert alert-danger">
                            <p> <?php echo e(Session::get('delete_error_message')); ?></p>
                        </div>
                <?php endif; ?>
        <div class="content-tabla">
                <div class="panel panel-border panel-inverse" style="margin-top: 5px">
                    <div class="panel-heading">
                     
                    </div>
                    <table class="table table-hover table-responsive table-striped table-condensed">
                        <thead>
                            <tr>
                                <th style="width: 300px; overflow:hidden;" class="cel_fix"><h5>Origen</h5></th>
                                <th class="cel_fix"><h5>Asunto</h5></th>
                                <th class="cel_fix"><h5>Fecha</h5></th>
                                <th style="width: 150px" class="cel_fix"></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($mensaje->leido): ?>
                                <tr class="mouse">
                                    <td style="width: 300px; overflow:hidden;" class="cel_fix"><?php echo e($mensaje->name); ?></td>
                                    <td class="cel_fix" style="overflow: hidden;"><?php echo e($mensaje->title); ?></td>
                                    <td class="cel_fix" style="overflow: hidden;"><?php echo e($mensaje->created_at); ?></td>
                                    <td style="width: 150px">
                                        <a class="btn btn-purple btn-sm" href="<?php echo e(route('vsent', ['id' => $mensaje->id])); ?>"><i class="fa fa-eye"></i></a>
                                        <button href="#" onclick="MessageDelete(<?php echo e($mensaje->id); ?>)" class="btn btn-danger btn-sm"><i class="fa fa-eraser"></i></button>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <tr class="mouse">
                                    <td style="width: 300px; overflow:hidden;" class="cel_fix"><strong><?php echo e($mensaje->name); ?></strong></td>
                                    <td class="cel_fix" style="overflow: hidden;"><strong><?php echo e($mensaje->title); ?></strong></td>
                                    <td class="cel_fix" style="overflow: hidden;"><?php echo e($mensaje->created_at); ?></td>
                                    <td style="width: 150px">
                                    <a class="btn btn-purple btn-sm" href="<?php echo e(route('vsent', ['id' => $mensaje->id])); ?>"><i class="fa fa-eye"></i></a>
                                    <button href="#" onclick="MessageDelete(<?php echo e($mensaje->id); ?>)" class="btn btn-danger btn-sm"><i class="fa fa-eraser"></i></button>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                 </table>
                <div class="panel-footer" style="padding: 2px 0 0 10px">
                     <paginator :tpage="totalpage" :pager="pager" v-on:getresult="getlist"></paginator>
                 </div>
                </div>
            </div>
        </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>