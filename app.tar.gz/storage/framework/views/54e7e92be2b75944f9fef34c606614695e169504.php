<?php $__env->startSection('content'); ?>
  <div class="row">
        <div class="col-xs-12">
            <div class="page-title-box">
                <h4 class="page-title">Mensajes</h4>
                <ol class="breadcrumb p-0 m-0">
                    <li>
                        <a href="#">Wusi</a>
                    </li>
                    <li>
                        <a href="#">Mensajes</a>
                    </li>
                </ol>
                <div class="clearfix"></div>
            </div>
        </div>
  </div>
  <div class="tabpanel">
        <div class="col-md-2">
            <ul class="nav nav-pills nav-stacked">
                <li class="active"><a href="<?php echo e(route('crear')); ?>">Redactar</a></li>
                <li><a href="<?php echo e(route('mensaje')); ?>">Recibidos</a></li>
                <li><a href="#">Borradores</a></li>
                <li><a href="<?php echo e(route('enviados')); ?>">Enviados</a></li>
            </ul>
        </div>
        <div class="col-md-10">
            <?php if(count($errors) > 0): ?>
			    <div class="alert alert-danger">
			        <ul>
			            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			        </ul>
			    </div>
            <?php endif; ?>
            <form id="send_menssage" action="<?php echo e(route('store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="card-body">
                    <div class="form-group">
                        <select id="recipient_id" name="recipient_id" class="form-control">
                            <option value="">Seleccionar destinatario</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input id="text-input" name="title" class="form-control" placeholder="Asunto..." type="text">
                    </div>
                    <div class="form-group">
                        <textarea class="ckeditor" name="body" id="body" cols="9" rows="10" placeholder="Escriba el mensaje..."></textarea>    
                    </div>
                    <div class="form-group">
                        <label class="control-label">Adjuntar archivo</label>
                        <input type="file" name="file" >
                    </div>
            </div>
            <div class="card-footer">
            <button type="submit" formmethod="post" formaction="<?php echo e(route('store')); ?>" class="btn btn-sm btn-primary">
                <i class="fa fa-dot-circle-o"></i> Enviar</button>
            </div>
            </form>
        </div>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>