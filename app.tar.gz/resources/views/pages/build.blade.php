@extends('layouts.app')
@section('content')
 @parent
  <div class="row">
        <div class="col-xs-12">
            <div class="page-title-box">
                <h4 class="page-title">Inicio</h4>
                <ol class="breadcrumb p-0 m-0">
                    <li>
                        <a href="#">Fundeeh</a>
                    </li>
                    <li>
                        <a href="#">Inicio</a>
                    </li>
                </ol>
                <div class="clearfix"></div>
            </div>
        </div>
  </div>
  <p>En construcción!!</p>
@endsection
